Whisper development report evidence. Open docs/validation/2026-11-03-whisper-development.md.
Includes all four results, methods, frozen configs, logs and tables. Raw recordings/transcripts/checkpoint weights remain in private local runs.
Validation-only evidence; final test and serving acceptance are not included. VIVOS use is academic, CC BY-NC-SA4.0; see report attribution.
